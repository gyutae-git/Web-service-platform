<?php
// Begin AIOWPSEC Firewall
if (file_exists('/home/admin/htdocs/lg.kimgyutae.com/aios-bootstrap.php')) {
	include_once('/home/admin/htdocs/lg.kimgyutae.com/aios-bootstrap.php');
}
// End AIOWPSEC Firewall
